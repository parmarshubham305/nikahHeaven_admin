export let userCollection = 'Users';
export let swipeCardCollection = 'SwipeCards';
export let matchesCollection = 'Matches';
export let conversationCollection = 'Conversations';
export let seekerRequestCollection = 'SeekerRequest';
export let notificationCollection = 'Notifications';
