import React, {useState, useEffect} from 'react';
import {useHistory, useLocation} from 'react-router-dom';
import {
  CRow,
} from '@coreui/react';

const ReportedUsers = () => {

  return (
    <CRow>

    </CRow>
  );
};

export default ReportedUsers;
