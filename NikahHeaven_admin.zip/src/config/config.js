export const WEB_CLIENT_ID = '602164921281-4ub1ti3jpero98atollsjmr12sv205h4.apps.googleusercontent.com';
export const CLOUDINARY_PRESENT_NAME = 'xv99gfhp';
export const CLOUDINARY_CLOUD_NAME = 'dyv2pftfd';
export const STRIPE_PUBLIC_KEY = 'pk_test_51N3SR4SD6UvKCkuQSGbaw6dhFyPeeHM51cdHBA1fOGvbxt4LEVjhOsZeKTkZ0QrAPECCeFMiS6gY3HXejfXDqdq5002uik7qth';
export const STRIPE_CLOUD_SERVER_URL = 'http://localhost:5000/epicbae-246b2/us-central1/payWithStripe';
export const IS_STRIPE_LIVE = false;
